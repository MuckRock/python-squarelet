# python-squarelet
Python wrapper for Squarelet, allowing for authentication and providing a request interface 
